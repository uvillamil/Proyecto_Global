from .UserCreateView import UserCreateView
from .UserDetailView import UserDetailView
